$(document).ready( function () {
  $(document).find('body').append('<div id="qunit-fixture"></div>');
});